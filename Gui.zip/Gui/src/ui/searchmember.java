package ui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class searchmember extends JFrame {

	private JPanel contentPane;
	private JTable table;

	DefaultTableModel model;
	private JButton btnNewButton_1;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public searchmember() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		scrollPane.setBounds(95, 36, 234, 127);
		contentPane.add(scrollPane);
		
		Object contents[][] = new Object [0][3];
		 String header[] = {"NAME", "ID", "PHONE"};
		 model = new DefaultTableModel(contents, header);
		
		table = new JTable(model);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("\uC870\uD68C");
		btnNewButton.addActionListener(new ActionListener() {
					
				     private String db_name;
			         private String db_id;
			         private String db_phone;

			         public void actionPerformed(ActionEvent arg0) {
			            model.setNumRows(0);
			           db.dbConnect();
			            try {
			               
			            	db.query("select", "select * from member");
			               while(db.rs.next()) {
			                  
			                  db_name = db.rs.getString("name_t");
			                  db_id = db.rs.getString("id_t");
			                  db_phone = db.rs.getString("phone_t");
			            
			                  Object data[] = {db_name, db_id, db_phone};
			                  model.addRow(data);
			                  }
			               } catch(Exception e1) {
			                  e1.printStackTrace();
			            }
			            
			         }
			      });
				
		
		btnNewButton.setBounds(209, 186, 91, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SubMain().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(78, 186, 91, 23);
		contentPane.add(btnNewButton_1);
	}

}
