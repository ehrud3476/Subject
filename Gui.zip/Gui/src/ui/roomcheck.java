package ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class roomcheck extends JFrame {

	private JPanel contentPane;
	static JTextField inputMemberid;
	static JTextField inputRoomnumber;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel_3;
	static JTextField inputRoomgrade;
	private JLabel lblNewLabel_4;
	static JTextField inputRoomprice;
	
	

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public roomcheck() {
		
			
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0\uBC88\uD638");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(42, 56, 50, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uAC1D\uC2E4 \uBC88\uD638");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setBounds(25, 81, 67, 15);
		contentPane.add(lblNewLabel_2);
		
		
		inputMemberid = new JTextField();
		inputMemberid.setBounds(104, 53, 96, 21);
		contentPane.add(inputMemberid);
		inputMemberid.setColumns(10);
		
		inputRoomnumber = new JTextField();
		inputRoomnumber.setBounds(104, 78, 96, 21);
		contentPane.add(inputRoomnumber);
		inputRoomnumber.setColumns(10);
		
		btnNewButton = new JButton("\uC608\uC57D\uD558\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					db.query("insert", "insert into reservation(`memberid_t`,`roomnumber`)"
							+ "values ('" + inputMemberid.getText() + "','" + inputRoomnumber.getText() + "')"); 
					JOptionPane.showMessageDialog(null, "�����̿Ϸ�Ǿ����ϴ�");
				}
				
				catch(Exception e1) {
					e1.printStackTrace();		
					
				}
				dispose();
			}
			});
				
		btnNewButton.setBounds(109, 199, 91, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Room().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(109, 232, 91, 23);
		contentPane.add(btnNewButton_1);
		
		lblNewLabel_3 = new JLabel("\uAC1D\uC2E4 \uB4F1\uAE09");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_3.setBounds(25, 106, 67, 15);
		contentPane.add(lblNewLabel_3);
		
		inputRoomgrade = new JTextField();
		inputRoomgrade.setBounds(104, 103, 96, 21);
		contentPane.add(inputRoomgrade);
		inputRoomgrade.setColumns(10);
		
		lblNewLabel_4 = new JLabel("\uAC1D\uC2E4 \uAC00\uACA9");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_4.setBounds(12, 131, 80, 15);
		contentPane.add(lblNewLabel_4);
		
		inputRoomprice = new JTextField();
		inputRoomprice.setBounds(104, 128, 96, 21);
		contentPane.add(inputRoomprice);
		inputRoomprice.setColumns(10);
	}

		}
