package ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class updateIn extends JFrame {

	private JPanel contentPane;
	private JTextField inputName;
	private JTextField inputId;
	private JTextField inputPasswd;
	private JTextField inputPassword;
	private JTextField inputTel;
	private JTextField inputBirth;
	/**
	 * @wbp.nonvisual location=197,4
	 */
	private final JButton button = new JButton("New button");
	private JButton btnNewButton;
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public updateIn() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel Name = new JLabel("\uC774\uB984");
		Name.setHorizontalAlignment(SwingConstants.RIGHT);
		Name.setBounds(26, 26, 50, 15);
		contentPane.add(Name);
		
		JLabel Id = new JLabel("\uC544\uC774\uB514");
		Id.setHorizontalAlignment(SwingConstants.RIGHT);
		Id.setBounds(26, 66, 50, 15);
		contentPane.add(Id);
		
		JLabel Passwd = new JLabel("\uBE44\uBC00\uBC88\uD638");
		Passwd.setHorizontalAlignment(SwingConstants.RIGHT);
		Passwd.setBounds(26, 105, 50, 15);
		contentPane.add(Passwd);
		
		JLabel Tel = new JLabel("\uD734\uB300\uD3F0\uBC88\uD638");
		Tel.setHorizontalAlignment(SwingConstants.RIGHT);
		Tel.setBounds(0, 175, 76, 15);
		contentPane.add(Tel);
		
		JLabel PassWord = new JLabel("\uBE44\uBC00\uBC88\uD638\uD655\uC778");
		PassWord.setHorizontalAlignment(SwingConstants.RIGHT);
		PassWord.setBounds(0, 139, 76, 15);
		contentPane.add(PassWord);
		
		JLabel Birth = new JLabel("\uC0DD\uB144\uC6D4\uC77C");
		Birth.setHorizontalAlignment(SwingConstants.RIGHT);
		Birth.setBounds(26, 214, 50, 15);
		contentPane.add(Birth);
		
		inputName = new JTextField();
		inputName.setBounds(88, 23, 96, 21);
		contentPane.add(inputName);
		inputName.setColumns(10);
		
		inputId = new JTextField();
		inputId.setBounds(88, 63, 96, 21);
		contentPane.add(inputId);
		inputId.setColumns(10);
		
		inputPasswd = new JTextField();
		inputPasswd.setBounds(88, 102, 96, 21);
		contentPane.add(inputPasswd);
		inputPasswd.setColumns(10);
		
		inputPassword = new JTextField();
		inputPassword.setBounds(88, 136, 96, 21);
		contentPane.add(inputPassword);
		inputPassword.setColumns(10);
		
		inputTel = new JTextField();
		inputTel.setBounds(88, 172, 96, 21);
		contentPane.add(inputTel);
		inputTel.setColumns(10);
		
		inputBirth = new JTextField();
		inputBirth.setBounds(88, 211, 96, 21);
		contentPane.add(inputBirth);
		inputBirth.setColumns(10);
		
		btnNewButton = new JButton("\uC218\uC815\uD558\uAE30");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				db.dbConnect();
				try {
					db.query("update", "update member set name_t = '"+inputName.getText()+"', id_t = '"+inputId.getText()+"', passwd_t='"+inputPasswd.getText()+"',password_t='"+inputPassword.getText()+"', phone_t='"+inputTel.getText()+"', birthday_t='"+inputBirth.getText()+"' where id_t = '"+inputId.getText()+"'");
				}
				catch(Exception e1){
					e1.printStackTrace();
				}
				new Main().setVisible(true);
				dispose();
			}
		});
			
			
		
		
		btnNewButton.setBounds(271, 171, 91, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Main().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(271, 210, 91, 23);
		contentPane.add(btnNewButton_1);
	}
}
