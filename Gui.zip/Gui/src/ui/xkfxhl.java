package ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;

public class xkfxhl extends JFrame {

	private JPanel contentPane;
	private JTextField inputId;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public xkfxhl() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("\uD0C8\uD1F4\uD655\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			db.dbConnect();
				
				try {
					db.query("delete", "delete from member where id_t = " + "'" + inputId.getText() + "'");
					//viewData();
					System.out.println("�����ͺ��̽� �����Ϸ�");
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				new SubMain().setVisible(true);
				dispose();
			}
		});
				
			
		
	
		btnNewButton.setBounds(231, 113, 91, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Main().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(94, 113, 91, 23);
		contentPane.add(btnNewButton_1);
		
		inputId = new JTextField();
		inputId.setBounds(231, 52, 96, 21);
		contentPane.add(inputId);
		inputId.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514\uD655\uC778");
		lblNewLabel.setBounds(128, 55, 91, 15);
		contentPane.add(lblNewLabel);
	}
}

