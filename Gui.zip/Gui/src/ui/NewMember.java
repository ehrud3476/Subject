package ui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;




public class NewMember extends JFrame {
	
	private static final Object btnNewButton = null;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;	
	static long count =0;
	

	private JPanel contentPane;
	private JTextField name_t;
	private  JTextField id_t;
	private JTextField passwd_t;
	private JTextField password_t;
	private JTextField phone_t;
	private JTextField birthday_t;
	private JTextField memberid_t;

	/**
	 * Launch the application.
	 */


	
	public NewMember() {
		db.dbConnect();
		setTitle("ȸ������â");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBackground(Color.LIGHT_GRAY);
		lblNewLabel.setBounds(46, 56, 50, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(46, 81, 50, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("\uBE44\uBC00\uBC88\uD638\uD655\uC778");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setBounds(12, 106, 84, 15);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("\uD734\uB300\uD3F0 \uBC88\uD638");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_2.setBounds(12, 131, 84, 15);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("\uC0DD\uB144\uC6D0\uC77C");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_3.setBounds(12, 156, 84, 15);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_2 = new JLabel("\uC774\uB984");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_2.setBounds(46, 31, 50, 15);
		contentPane.add(lblNewLabel_2);
		
		name_t = new JTextField();
		name_t.setBounds(108, 28, 96, 21);
		contentPane.add(name_t);
		name_t.setColumns(10);
		
		id_t = new JTextField();
		id_t.setColumns(10);
		id_t.setBounds(108, 53, 96, 21);
		contentPane.add(id_t);
		
		passwd_t = new JTextField();
		passwd_t.setColumns(10);
		passwd_t.setBounds(108, 78, 96, 21);
		contentPane.add(passwd_t);
		
		password_t = new JTextField();
		password_t.setColumns(10);
		password_t.setBounds(108, 103, 96, 21);
		contentPane.add(password_t);
		
		memberid_t = new JTextField();
		memberid_t.setBounds(108, 3, 96, 21);
		contentPane.add(memberid_t);
		memberid_t.setColumns(10);
		
		JButton newMember = new JButton("\uD68C\uC6D0\uAC00\uC785");
		newMember.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == newMember) {

			
					try {
						
						db.query("insert", "insert into member(`memberid_t`,`name_t`,`id_t`,`passwd_t`,`password_t`,`phone_t`,`birthday_t`) "
								+ "values('" + memberid_t.getText() + "','" + name_t.getText() + "','" + id_t.getText() + "','" + passwd_t.getText() + "','" + password_t.getText() + "','" + phone_t.getText() + "','" + birthday_t.getText() + "')");

									

								} catch (Exception e1) {

									e1.printStackTrace();

								}
								System.out.println("���׸��߰�");
								name_t.setText(" ");
								id_t.setText(" ");
								passwd_t.setText(" ");
								password_t.setText(" ");
								phone_t.setText(" ");
								birthday_t.setText(" ");

				new Main().setVisible(true);
				dispose();
			}	
		}});
	
		newMember.setBounds(66, 184, 91, 23);
		contentPane.add(newMember);
		
		JButton btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SubMain().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(185, 184, 91, 23);
		contentPane.add(btnNewButton_1);
		
		phone_t = new JTextField();
		phone_t.setBounds(108, 128, 147, 21);
		contentPane.add(phone_t);
		phone_t.setColumns(10);
		
		birthday_t = new JTextField();
		birthday_t.setBounds(108, 153, 117, 21);
		contentPane.add(birthday_t);
		birthday_t.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("\uD68C\uC6D0\uBC88\uD638");
		lblNewLabel_3.setBounds(46, 6, 50, 15);
		contentPane.add(lblNewLabel_3);
		

		}
	}

	

		
		
		
			
			
		



			
		
	

			



