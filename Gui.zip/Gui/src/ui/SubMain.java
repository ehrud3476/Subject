package ui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class SubMain extends JFrame {
	
	private JPanel contentPane;
	 static JTextField inputId;
	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;	
	static long count =0;
	private JPasswordField inputPasswd;

	

        	
	public SubMain() {		

		setTitle("�α��� �� ȭ��");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 436, 283);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\uB85C\uADF8\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4.");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(124, 57, 132, 36);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(75, 103, 50, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("PASSWARD");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1_1.setBounds(41, 128, 84, 15);
		contentPane.add(lblNewLabel_1_1);
		
		inputId = new JTextField();
		inputId.setForeground(Color.LIGHT_GRAY);
		inputId.setBounds(134, 97, 122, 21);
		contentPane.add(inputId);
		inputId.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new NewMember().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(283, 95, 91, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Login");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				db.dbConnect();
			
				String pw = ""; 
				char[] secret_pw = inputPasswd.getPassword(); 
				
				for(char cha : secret_pw){
					Character.toString(cha);
				 pw += (pw.equals("")) ? ""+cha+"" : ""+cha+"";
				 }
				try {
					while(db.rs.next()) {
						if(inputId.getText().equals(db.rs.getString("id_t")))
						
						if(pw.equals(db.rs.getString("passwd_t"))) {
							
							new Main().setVisible(true);
							dispose();
							return;
						}
					}
				
				JOptionPane.showMessageDialog(contentPane, "���� Ʋ��");
			}
				catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}			
				db.dbDis();
			}
		});
		btnNewButton_2.setBounds(283, 125, 91, 21);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton = new JButton("\uAD00\uB9AC\uC790 \uBAA8\uB4DC");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new admin().setVisible(true);
				
			}
		});
		btnNewButton.setBounds(12, 213, 113, 23);
		contentPane.add(btnNewButton);
		
		inputPasswd = new JPasswordField();
		inputPasswd.setBounds(134, 125, 122, 21);
		contentPane.add(inputPasswd);
		
	}
}


