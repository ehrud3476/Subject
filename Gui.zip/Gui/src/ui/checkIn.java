package ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class checkIn extends JFrame {

	private JPanel contentPane;
	static JTextField rnumber;
	static JTextField rgrade;
	 static JTextField rprice;
	 static JTextField mberid;

	/**
	 * Launch the application.
	 */
	
	/**
	 * Create the frame.
	 */
	public checkIn() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\uAC1D\uC2E4 \uBC88\uD638");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(12, 64, 106, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uAC1D\uC2E4 \uB4F1\uAE09");
		lblNewLabel_1.setBounds(68, 106, 50, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uAC1D\uC2E4 \uAC00\uACA9");
		lblNewLabel_2.setBounds(68, 142, 50, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_4 = new JLabel("\uC608\uC57D \uB0B4\uC5ED");
		lblNewLabel_4.setBounds(154, 10, 50, 15);
		contentPane.add(lblNewLabel_4);
		
		rnumber = new JTextField();
		rnumber.setBounds(130, 61, 96, 21);
		contentPane.add(rnumber);
		rnumber.setColumns(10);
		
		rgrade = new JTextField();
		rgrade.setBounds(130, 103, 96, 21);
		contentPane.add(rgrade);
		rgrade.setColumns(10);
		
		rprice = new JTextField();
		rprice.setBounds(130, 139, 96, 21);
		contentPane.add(rprice);
		rprice.setColumns(10);
		
		JButton btnNewButton = new JButton("\uC608\uC57D\uCDE8\uC18C");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	db.dbConnect();
				
				try {
					db.query("delete", "delete from reservation where memberid_t  = " + "'" + mberid.getText() + "'");
					//viewData();
					System.out.println("�����ͺ��̽� �����Ϸ�");
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				new Main().setVisible(true);
				dispose();
			}
		});
			
		btnNewButton.setBounds(255, 192, 91, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Main().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(113, 192, 91, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("\uD68C\uC6D0 \uBC88\uD638");
		lblNewLabel_3.setBounds(68, 39, 50, 15);
		contentPane.add(lblNewLabel_3);
		
		mberid = new JTextField();
		mberid.setBounds(130, 30, 96, 21);
		contentPane.add(mberid);
		mberid.setColumns(10);
	}

}
