package ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class Room extends JFrame {

	protected static final String Roomnumber = null;
	private JPanel contentPane;
	DefaultTableModel model1;
	private JTable table1;
	
	
	/**
	 * Create the frame.
	 */ 

	public Room() {
	
		setTitle("��������");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		
			
		scrollPane.setBounds(27, 40, 234, 127);
		contentPane.add(scrollPane);
		
		Object contents[][] = new Object [0][3];
		 String header[] = {"���ǹ�ȣ", "���ǵ��", "���ǰ���"};
		 model1 = new DefaultTableModel(contents, header);

		 table1 = new JTable(model1);
		 table1.addMouseListener(new MouseAdapter() {
			 @Override
			 public  void mouseClicked(MouseEvent e) {
				 
				 
				int row = table1.getSelectedRow();
				TableModel data = table1.getModel();
				
				String r_number = (String)data.getValueAt(row, 0);
				String r_grade = (String)data.getValueAt(row, 1);
				String r_price = (String)data.getValueAt(row, 2);
				
				
			
				new roomcheck().setVisible(true);
				
						
		
				roomcheck.inputRoomnumber.setText(r_number);
				roomcheck.inputRoomgrade.setText(r_grade);
				roomcheck.inputRoomprice.setText(r_price);
				
				
			 }
		 });
		
		
				
		 
	
	
		scrollPane.setViewportView(table1);
		
		JButton btnNewButton_1 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Main().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(106, 195, 91, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\uAC1D\uC2E4\uC870\uD68C\uD558\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			
				 private String db_roomnumber;
		         private String db_roomgrade;
		         private String db_roomprice;

		         public void actionPerformed(ActionEvent arg0) {
		            model1.setNumRows(0);
		           db.dbConnect();
		            try {
		               
		            	db.query("select", "select * from room");
		               while(db.rs.next()) {
		                  
		                  db_roomnumber = db.rs.getString("roomnumber");
		                  db_roomgrade = db.rs.getString("roomgrade");
		                  db_roomprice = db.rs.getString("roomprice");
		            
		                  Object data[] = {db_roomnumber, db_roomgrade, db_roomprice};
		                  model1.addRow(data);
		                  }
		               } catch(Exception e1) {
		                  e1.printStackTrace();
		            }
		            
		         }
		      });
			
		
		btnNewButton_2.setBounds(286, 144, 119, 23);
		contentPane.add(btnNewButton_2);
		
		
	}
}
		
	
